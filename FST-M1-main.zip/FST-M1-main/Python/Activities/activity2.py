num=int(input("enter a number: "))
if (num % 2) > 0:
    print("You picked an odd number")
else:
    print("You picked an even number")