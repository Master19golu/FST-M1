num= list(input("enter list:").split(","))
a=num[0]
if(a==num[-1]):
    print("True")
else:
    print("False")