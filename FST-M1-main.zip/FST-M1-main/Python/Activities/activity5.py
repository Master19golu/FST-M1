num=int(input("enter a number: "))
for i in range(2,11,2):
    print (num, '*', i, '=',num*i)

    
