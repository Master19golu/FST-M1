num= list(input("enter list:").split(","))
sum=0
for i in num:
    sum+=int(i)
print(sum)